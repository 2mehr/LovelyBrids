﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class MenuManger : MonoBehaviour {
    public Texture2D instaShire;
    bool isMute;
    public Image Mute;
    private bool isProcessing = false;
    public Image Panel_Ch;
    public Image Butten_Page_Ch;
    bool ISNext ;
    // Use this for initialization
    void Awake () {
        Camera.main.GetComponent<AudioSource>().mute = bool.Parse(PlayerPrefs.GetString("Sound"));
        Mute.enabled = bool.Parse(PlayerPrefs.GetString("Sound")); ;
        PlayerPrefs.SetInt("plus", 0);
    }
	
	// Update is called once per frame
	void Update () {
       
	}
    public void PlayGame()
    {
        SceneManager.LoadScene(1);
    }
    public void shire()
    {
      //  AndroidSocialGate.StartShareIntent("Hello Share Intent", "This is my text to share", instaShire);

    }
  public void Instageram()
    {
      //  AndroidInstagramManager.Instance.Share(instaShire, "I am posting from my app");

    }
    public void Telegram()
    {
       // AndroidSocialGate.StartShareIntent("Hello Share Intent", "This is my text to share", instaShire, "com.telegram");
    }
    // Is play Sound For Game
    string _mute;
    public void Sound()
    {
        isMute = bool.Parse(PlayerPrefs.GetString("Sound"));
        isMute = !isMute;
        if (isMute == true)
        {
            Mute.enabled = true;
            _mute = Mute.enabled.ToString();
        }
        else
        {
            Mute.enabled = false;
            _mute = Mute.enabled.ToString();
        }

       
        // Save Poistion Sound 
        PlayerPrefs.SetString("Sound", _mute);
    }
    /// <summary>
    /// Page Character 
    /// </summary>
    public void ShowPanel_Ch()
    {
        Panel_Ch.gameObject.SetActive (true);
    }
    public void HidePanel_Ch()
    {
        Panel_Ch.gameObject.SetActive(false);
    }
    public void Next_Page_char()
    {
        ISNext = !ISNext;
        if (ISNext == true)
        {
            Panel_Ch.GetComponentInChildren<Animator>().enabled = true;
            // Butten_Page_Ch.transform.Rotate(new Vector3(0, 180, 0));
            Panel_Ch.GetComponentInChildren<Animator>().Play("Page_Ch Animation");

        }
        else
        {
            Panel_Ch.GetComponentInChildren<Animator>().Play("Page_Ch Animation 0");
          //  Panel_Ch.GetComponentInChildren<Animator>().enabled = false;
        }


        print(ISNext);
    }
   
   
    public void ExitGame()
    {
        Application.Quit();
    }

   

  

}
