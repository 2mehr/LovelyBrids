﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System;

public class Manger_Game : MonoBehaviour {

    public delegate int Plus_GameOver();
    public static event Plus_GameOver P_Video;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void Butten_Hom()
    {
        StartCoroutine(Butten_Home());
    }
    private IEnumerator Butten_Home()
    {
        yield return new WaitForSeconds(0.3f);
        SceneManager.LoadSceneAsync(0);
    }
    public void Tapligh_GameOver()
    {

    }
    public void Reset()
    {
        
        SceneManager.LoadScene(1);
    }
}
