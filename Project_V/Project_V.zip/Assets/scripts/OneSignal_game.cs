﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OneSignal_game : MonoBehaviour {

	// Use this for initialization
	void Start () {
        OneSignal.StartInit("12b7bba2-22e9-450f-b991-ecb57d74b653")
       .HandleNotificationOpened(HandleNotificationOpened)
       .EndInit();

        OneSignal.inFocusDisplayType = OneSignal.OSInFocusDisplayOption.Notification;
    }

    // Gets called when the player opens the notification.
    private static void HandleNotificationOpened(OSNotificationOpenedResult result)
    {
        
    }

    // Update is called once per frame
    void Update () {
		
	}
}
