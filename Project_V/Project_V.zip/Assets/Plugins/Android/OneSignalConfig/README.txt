Android Setup
=====================

1. Replace the example small notification icons in the res folder with your own with by follwing the insturctions below.
  - https://documentation.onesignal.com/docs/android-notification-customizations#small-notification-icon
2. The large notification icon is optional, remove or replace res/drawable-xxhdpi-v11/ic_onesignal_large_icon_default.png.