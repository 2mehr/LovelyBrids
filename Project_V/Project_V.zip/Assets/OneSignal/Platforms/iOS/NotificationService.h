//
//  NotificationService.h
//  OneSignalNotificationServiceExtension
//
//  Created by Kasten on 3/10/17.
//  Copyright © 2017 OneSignal. All rights reserved.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
